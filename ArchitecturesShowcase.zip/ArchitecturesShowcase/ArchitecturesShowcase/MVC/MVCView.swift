import UIKit

final class MVCView: UIView {
    
}
